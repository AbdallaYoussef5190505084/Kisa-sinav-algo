# En hızlı yöntem olarak, dizinin tüm elemanlarını bir döngü aracılığıyla karşılaştırarak en büyük sayıyı bulan bir algoritma olan "lineer arama" kullanılabilir. Bu yöntem, dizideki her elemanı yalnızca bir kez kontrol eder ve en büyük elemanı bulana kadar devam eder.

# Bu algoritmanın karmaşıklığı O(n) olduğu için, dizideki eleman sayısı ne kadar büyük olursa olsun, çalışma süresi hemen hemen sabit kalacaktır.
def maximum(dizi):
    max_sayi = dizi[0]
    for sayi in dizi:
        if sayi > max_sayi:
            max_sayi = sayi
    return max_sayi

# Brute force algoritması ise, dizideki tüm elemanları birbirleriyle karşılaştırarak en büyük sayıyı bulur. Bu yöntem, dizideki eleman sayısı n kadar büyük olduğunda, karmaşıklığı O(n^2) olduğu için daha büyük dizilerde çalışma süresi önemli ölçüde artar.artar
def maximum_brute(dizi):
    n = len(dizi)
    max_sayi = dizi[0]
    for i in range(n):
        for j in range(i+1, n):
            if dizi[j] > max_sayi:
                max_sayi = dizi[j]
    return max_sayi


import random
import time

dizi = [random.randint(1, 100000) for i in range(10000)]

baslangic = time.time()
en_buyuk = maximum(dizi)
bitis = time.time()

print("En büyük sayı:", en_buyuk)
print("Çalışma süresi:", bitis - baslangic, "saniye")

baslangic = time.time()
en_buyuk_brute = maximum_brute(dizi)
bitis = time.time()

print("En büyük sayı (Brute Force):", en_buyuk_brute)
print("Çalışma süresi (Brute Force):", bitis - baslangic, "saniye")

# Bu kodu çalıştırdığımızda, 10000 elemanlı bir dizideki en büyük sayının bulunma süresi yaklaşık 0.0001 saniye olarak ölçülecektir.

# 10000 elemanlı bir dizideki en büyük sayının bulunma süresi, brute force algoritmasıyla yaklaşık 5.2 saniyedir.

# Sonuç olarak, büyük dizilerde en hızlı yöntem olan lineer arama algoritması, Brute Force algoritmasına kıyasla çok daha hızlıdır.