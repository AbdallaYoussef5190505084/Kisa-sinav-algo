# Veri sıralama için en iyi algoritma, veri boyutuna ve verinin özelliklerine göre değişebilir. Ancak genel olarak, hızlı ve etkili sıralama algoritmalarından biri olarak "QuickSort" algoritması tercih edilebilir. QuickSort, ortalama durumda O(nlogn) zaman karmaşıklığına sahiptir


import random
import time
# 10000 sayılık rastgele dizi üzerinde QuickSort algoritmasını
def quickSort(arr, low, high):
    if low < high:
        pi = partition(arr, low, high)
        quickSort(arr, low, pi - 1)
        quickSort(arr, pi + 1, high)

def partition(arr, low, high):
    i = (low - 1)
    pivot = arr[high]

    for j in range(low, high):
        if arr[j] < pivot:
            i += 1
            arr[i], arr[j] = arr[j], arr[i]

    arr[i + 1], arr[high] = arr[high], arr[i + 1]
    return (i + 1)

# Test
arr = [random.randint(0, 10000) for i in range(10000)]
start_time = time.time()
quickSort(arr, 0, len(arr) - 1)
end_time = time.time()
print("QuickSort çalışma süresi: ", end_time - start_time, " saniye")
# Aynı dizi üzerinde BruteForce yöntemi kullanarak sıralama işlemi yapmak, tüm elemanların tüm elemanlarla karşılaştırıldığı O(n^2) zaman karmaşıklığına sahip olacaktır. Aşağıdaki gibi bir Python programı ile BruteForce sıralama algoritmasını gerçekleştirebiliriz:
def bruteForceSort(arr):
    for i in range(len(arr)):
        for j in range(i + 1, len(arr)):
            if arr[i] > arr[j]:
                arr[i], arr[j] = arr[j], arr[i]


arr = [random.randint(0, 10000) for i in range(10000)]
start_time = time.time()
bruteForceSort(arr)
end_time = time.time()
print("BruteForce sıralama çalışma süresi: ", end_time - start_time, " saniye")

# Yukarıdaki programlarla yapılan test sonuçlarına göre, QuickSort algoritması BruteForce yöntemine göre çok daha hızlıdır. Ancak QuickSort algoritmasının en kötü durumda zaman karmaşıklığı O(n^2) olabilir ve bu durumda BruteForce yöntemine benzer hızlarda çalışabilir.